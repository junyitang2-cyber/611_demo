public class Main {

    public static void main(String[] args) {
        AudioUtility.playSound(AudioUtility.DRAGON_ROAR,false,3f);
        BeginFrame begin = new BeginFrame();
    }
}
