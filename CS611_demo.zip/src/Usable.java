public interface Usable {

    //find which attributes are affected
    public int[] calcUse();
}
