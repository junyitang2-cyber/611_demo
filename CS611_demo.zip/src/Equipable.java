public interface Equipable {

    // equip or unequip an item
    public void equipItem();
    public void unequipItem();

}
