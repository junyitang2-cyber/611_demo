public abstract class RPGGame extends Game {

    public RPGGame(){

    }

    abstract public void playGame();
}
