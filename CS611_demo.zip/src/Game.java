public abstract class Game {
    abstract public void playGame();
}
